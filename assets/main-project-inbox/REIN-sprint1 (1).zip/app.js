(() => {
  'use strict';

  const STORAGE_KEYS = {
    properties: 'rein-mvp-properties-v1',
    needs: 'rein-mvp-needs-v1',
  };

  const state = {
    properties: readStorage(STORAGE_KEYS.properties),
    needs: readStorage(STORAGE_KEYS.needs),
  };

  const els = {
    propertyForm: document.querySelector('#propertyForm'),
    needForm: document.querySelector('#needForm'),
    propertyList: document.querySelector('#propertyList'),
    needList: document.querySelector('#needList'),
    propertyCount: document.querySelector('#propertyCount'),
    needCount: document.querySelector('#needCount'),
    propertyListCount: document.querySelector('#propertyListCount'),
    needListCount: document.querySelector('#needListCount'),
    matchSelect: document.querySelector('#matchNeedSelect'),
    matchSummary: document.querySelector('#matchSummary'),
    matchResults: document.querySelector('#matchResults'),
    propertyDealType: document.querySelector('#propertyDealType'),
    needDealType: document.querySelector('#needDealType'),
    propertyPriceField: document.querySelector('#propertyPriceField'),
    propertyDepositField: document.querySelector('#propertyDepositField'),
    propertyRentField: document.querySelector('#propertyRentField'),
    minBudgetLabel: document.querySelector('#minBudgetLabel'),
    maxBudgetLabel: document.querySelector('#maxBudgetLabel'),
    minMonthlyRentField: document.querySelector('#minMonthlyRentField'),
    maxMonthlyRentField: document.querySelector('#maxMonthlyRentField'),
    budgetHint: document.querySelector('#budgetHint'),
  };

  function readStorage(key) {
    try {
      const stored = JSON.parse(localStorage.getItem(key) || '[]');
      return Array.isArray(stored) ? stored : [];
    } catch {
      return [];
    }
  }

  function writeStorage(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch {
      return false;
    }
  }

  function numberValue(value) {
    return ReinMatching.parseNumber(value);
  }

  function optionalNumber(value) {
    const number = numberValue(value);
    return number === null ? null : number;
  }

  function normalize(value) {
    return String(value || '')
      .trim()
      .replace(/\s+/g, ' ')
      .replace(/ي/g, 'ی')
      .replace(/ك/g, 'ک')
      .toLocaleLowerCase('fa-IR');
  }

  function money(value) {
    return `${new Intl.NumberFormat('fa-IR').format(value || 0)} تومان`;
  }

  function faNumber(value) {
    return new Intl.NumberFormat('fa-IR').format(value || 0);
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function formDataToObject(form) {
    return Object.fromEntries(new FormData(form).entries());
  }

  function setMessage(id, message = '', type = '') {
    const target = document.querySelector(id);
    target.textContent = message;
    target.className = `form-message ${type}`.trim();
  }

  function saveProperties() {
    if (!writeStorage(STORAGE_KEYS.properties, state.properties)) return false;
    renderAll();
    return true;
  }

  function saveNeeds() {
    if (!writeStorage(STORAGE_KEYS.needs, state.needs)) return false;
    renderAll();
    return true;
  }

  function syncPropertyPriceFields() {
    const dealType = els.propertyDealType.value;
    const usesDeposit = ['رهن', 'اجاره', 'رهن و اجاره'].includes(dealType);
    const needsMonthlyRent = ['اجاره', 'رهن و اجاره'].includes(dealType);
    const priceInput = els.propertyPriceField.querySelector('input');
    const depositInput = els.propertyDepositField.querySelector('input');
    const rentInput = els.propertyRentField.querySelector('input');

    els.propertyPriceField.classList.toggle('is-hidden', usesDeposit);
    els.propertyDepositField.classList.toggle('is-hidden', !usesDeposit);
    els.propertyRentField.classList.toggle('is-hidden', !needsMonthlyRent);
    priceInput.required = !usesDeposit;
    depositInput.required = usesDeposit;
    rentInput.required = needsMonthlyRent;
    priceInput.disabled = usesDeposit;
    depositInput.disabled = !usesDeposit;
    rentInput.disabled = !needsMonthlyRent;
  }

  function syncNeedBudgetLabels() {
    const dealType = els.needDealType.value;
    const rental = ReinMatching.RENTAL_TYPES.includes(dealType);
    const monthlyRent = ReinMatching.MONTHLY_RENT_TYPES.includes(dealType);
    const required = '<b>*</b>';
    els.minBudgetLabel.innerHTML = `${rental ? 'حداقل رهن / ودیعه' : 'حداقل بودجه'} (تومان) ${required}`;
    els.maxBudgetLabel.innerHTML = `${rental ? 'حداکثر رهن / ودیعه' : 'حداکثر بودجه'} (تومان) ${required}`;
    els.minMonthlyRentField.classList.toggle('is-hidden', !monthlyRent);
    els.maxMonthlyRentField.classList.toggle('is-hidden', !monthlyRent);
    els.minMonthlyRentField.querySelector('input').required = monthlyRent;
    els.maxMonthlyRentField.querySelector('input').required = monthlyRent;
    els.minMonthlyRentField.querySelector('input').disabled = !monthlyRent;
    els.maxMonthlyRentField.querySelector('input').disabled = !monthlyRent;
    els.budgetHint.textContent = rental
      ? (monthlyRent
        ? 'برای اجاره و رهن و اجاره، بازهٔ رهن/ودیعه و بازهٔ اجارهٔ ماهانه مستقل و هر دو ضروری هستند.'
        : 'برای رهن، فقط بازهٔ رهن / ودیعه لازم است؛ اجارهٔ ماهانه برای این نوع معامله کاربرد ندارد.')
      : 'برای خرید و فروش، بودجه با قیمت کل ملک مقایسه می‌شود.';
  }

  function renderCounters() {
    els.propertyCount.textContent = faNumber(state.properties.length);
    els.needCount.textContent = faNumber(state.needs.length);
    els.propertyListCount.textContent = `${faNumber(state.properties.length)} مورد`;
    els.needListCount.textContent = `${faNumber(state.needs.length)} مورد`;
  }

  function propertyAmountLabel(property) {
    if (ReinMatching.RENTAL_TYPES.includes(property.dealType)) {
      const deposit = property.deposit === null || property.deposit === undefined ? 'ثبت نشده' : money(property.deposit);
      const monthly = ReinMatching.MONTHLY_RENT_TYPES.includes(property.dealType)
        ? (property.monthlyRent === null || property.monthlyRent === undefined ? 'اجارهٔ ماهانه ثبت نشده' : ` + ${money(property.monthlyRent)} اجاره`)
        : '';
      return `رهن / ودیعه ${deposit}${monthly}`;
    }
    return property.price === null || property.price === undefined ? 'قیمت ثبت نشده' : `قیمت ${money(property.price)}`;
  }

  function moneyRange(min, max) {
    const hasMin = Number.isFinite(min);
    const hasMax = Number.isFinite(max);
    if (hasMin && hasMax) return `${money(min)} تا ${money(max)}`;
    if (hasMin) return `از ${money(min)}`;
    if (hasMax) return `تا ${money(max)}`;
    return 'اطلاعات ثبت نشده';
  }

  function needFinancialLabel(need) {
    if (!ReinMatching.RENTAL_TYPES.includes(need.dealType)) {
      return `بازهٔ بودجه: ${moneyRange(need.minBudget, need.maxBudget)}`;
    }

    const deposit = ReinMatching.needRange(need, 'deposit');
    if (need.dealType === 'رهن') {
      return `بازهٔ ودیعه: ${moneyRange(deposit.min, deposit.max)}`;
    }

    const monthlyRent = ReinMatching.needRange(need, 'monthlyRent');
    return `بازهٔ ودیعه: ${moneyRange(deposit.min, deposit.max)} · بازهٔ اجارهٔ ماهانه: ${moneyRange(monthlyRent.min, monthlyRent.max)}`;
  }

  function renderProperties() {
    if (state.properties.length === 0) {
      els.propertyList.innerHTML = emptyState('هنوز ملکی ثبت نشده است.', 'برای شروع می‌توانید دادهٔ فرضی بارگذاری کنید یا فرم بالا را تکمیل کنید.');
      return;
    }

    els.propertyList.innerHTML = state.properties.map((property) => `
      <article class="record-card">
        <div class="record-topline">
          <span class="code-chip">${escapeHtml(property.code)}</span>
          <span class="deal-chip">${escapeHtml(property.dealType)}</span>
        </div>
        <h4>${escapeHtml(property.city)}، ${escapeHtml(property.neighborhood)}</h4>
        <p class="record-price">${propertyAmountLabel(property)}</p>
        <div class="record-meta">
          <span>${faNumber(property.area)} متر</span>
          <span>${faNumber(property.rooms)} اتاق</span>
          ${property.notes ? `<span>${escapeHtml(property.notes)}</span>` : ''}
        </div>
      </article>
    `).join('');
  }

  function renderNeeds() {
    if (state.needs.length === 0) {
      els.needList.innerHTML = emptyState('هنوز نیازی ثبت نشده است.', 'نام مستعار و معیارهای فرضی را در فرم بالا وارد کنید.');
      return;
    }

    els.needList.innerHTML = state.needs.map((need) => `
      <article class="record-card">
        <div class="record-topline">
          <span class="code-chip">${escapeHtml(need.alias)}</span>
          <span class="deal-chip">${escapeHtml(need.dealType)}</span>
        </div>
        <h4>${escapeHtml(need.city)}${need.neighborhood ? `، ${escapeHtml(need.neighborhood)}` : '، همهٔ محله‌ها'}</h4>
        <p class="record-price">${needFinancialLabel(need)}</p>
        <div class="record-meta">
          <span>متراژ: ${rangeText(need.minArea, need.maxArea, 'متر')}</span>
          <span>حداقل ${faNumber(need.rooms || 0)} اتاق</span>
          ${need.notes ? `<span>${escapeHtml(need.notes)}</span>` : ''}
        </div>
      </article>
    `).join('');
  }

  function rangeText(min, max, suffix) {
    if (min && max) return `${faNumber(min)} تا ${faNumber(max)} ${suffix}`;
    if (min) return `از ${faNumber(min)} ${suffix}`;
    if (max) return `تا ${faNumber(max)} ${suffix}`;
    return 'بدون محدودیت';
  }

  function emptyState(title, description) {
    return `<div class="empty-state"><span aria-hidden="true">◇</span><strong>${title}</strong><p>${description}</p></div>`;
  }

  function renderNeedSelect() {
    const selected = els.matchSelect.value;
    if (state.needs.length === 0) {
      els.matchSelect.innerHTML = '<option value="">ابتدا یک نیاز ثبت کنید</option>';
      els.matchSelect.disabled = true;
      document.querySelector('#runMatch').disabled = true;
      return;
    }

    els.matchSelect.disabled = false;
    document.querySelector('#runMatch').disabled = false;
    els.matchSelect.innerHTML = `<option value="">انتخاب نیاز</option>${state.needs.map((need) => `
      <option value="${need.id}">${escapeHtml(need.alias)} — ${escapeHtml(need.city)} / ${escapeHtml(need.dealType)}</option>
    `).join('')}`;
    if (state.needs.some((need) => need.id === selected)) els.matchSelect.value = selected;
  }

  function renderAll() {
    renderCounters();
    renderProperties();
    renderNeeds();
    renderNeedSelect();
  }

  function handlePropertySubmit(event) {
    event.preventDefault();
    if (!els.propertyForm.checkValidity()) {
      els.propertyForm.reportValidity();
      return;
    }
    const values = formDataToObject(els.propertyForm);
    const dealType = values.dealType;
    const property = {
      id: crypto.randomUUID(),
      code: values.code.trim(),
      city: values.city.trim(),
      neighborhood: values.neighborhood.trim(),
      dealType,
      price: optionalNumber(values.price),
      deposit: optionalNumber(values.deposit),
      monthlyRent: optionalNumber(values.monthlyRent),
      area: optionalNumber(values.area),
      rooms: optionalNumber(values.rooms),
      notes: values.notes.trim(),
      createdAt: new Date().toISOString(),
    };

    const usesDeposit = ['رهن', 'اجاره', 'رهن و اجاره'].includes(dealType);
    const needsMonthlyRent = ['اجاره', 'رهن و اجاره'].includes(dealType);
    const codeTaken = state.properties.some((item) => normalize(item.code) === normalize(property.code));

    if (!property.code || !property.city || !property.neighborhood || property.area === null || property.rooms === null) {
      setMessage('#propertyMessage', 'لطفاً همهٔ فیلدهای ضروری را کامل کنید.', 'is-error');
      return;
    }
    if (property.area <= 0 || property.rooms < 0 || [property.price, property.deposit, property.monthlyRent].some((value) => value !== null && value < 0)) {
      setMessage('#propertyMessage', 'متراژ باید مثبت و تعداد اتاق و مبالغ نمی‌توانند منفی باشند.', 'is-error');
      return;
    }
    if (codeTaken) {
      setMessage('#propertyMessage', 'این کد ملک قبلاً ثبت شده است. یک کد فرضی متفاوت وارد کنید.', 'is-error');
      return;
    }
    if ((!usesDeposit && property.price === null) || (usesDeposit && property.deposit === null) || (needsMonthlyRent && property.monthlyRent === null)) {
      setMessage('#propertyMessage', 'مبلغ مناسب برای نوع معامله را وارد کنید.', 'is-error');
      return;
    }

    state.properties.unshift(property);
    if (!saveProperties()) {
      state.properties.shift();
      renderAll();
      setMessage('#propertyMessage', 'ذخیره‌سازی مرورگر در دسترس نیست؛ ملک ثبت نشد.', 'is-error');
      return;
    }
    els.propertyForm.reset();
    els.propertyDealType.value = 'فروش';
    syncPropertyPriceFields();
    setMessage('#propertyMessage', `ملک فرضی «${property.code}» ثبت شد و در جست‌وجو قابل بررسی است.`, 'is-success');
  }

  function handleNeedSubmit(event) {
    event.preventDefault();
    if (!els.needForm.checkValidity()) {
      els.needForm.reportValidity();
      return;
    }
    const values = formDataToObject(els.needForm);
    const need = {
      id: crypto.randomUUID(),
      alias: values.alias.trim(),
      city: values.city.trim(),
      neighborhood: values.neighborhood.trim(),
      dealType: values.dealType,
      minBudget: optionalNumber(values.minBudget),
      maxBudget: optionalNumber(values.maxBudget),
      minDeposit: null,
      maxDeposit: null,
      minMonthlyRent: optionalNumber(values.minMonthlyRent),
      maxMonthlyRent: optionalNumber(values.maxMonthlyRent),
      minArea: optionalNumber(values.minArea),
      maxArea: optionalNumber(values.maxArea),
      rooms: optionalNumber(values.rooms),
      notes: values.notes.trim(),
      createdAt: new Date().toISOString(),
    };

    const rental = ReinMatching.RENTAL_TYPES.includes(need.dealType);
    const monthlyRentRequired = ReinMatching.MONTHLY_RENT_TYPES.includes(need.dealType);
    need.minDeposit = rental ? need.minBudget : null;
    need.maxDeposit = rental ? need.maxBudget : null;
    if (!need.alias || !need.city || need.minBudget === null || need.maxBudget === null) {
      setMessage('#needMessage', 'نام مستعار، شهر و بازهٔ مالی ضروری هستند.', 'is-error');
      return;
    }
    if ([need.minBudget, need.maxBudget, need.minMonthlyRent, need.maxMonthlyRent, need.minArea, need.maxArea, need.rooms].some((value) => value !== null && value < 0)) {
      setMessage('#needMessage', 'مبالغ، متراژ و تعداد اتاق نمی‌توانند منفی باشند.', 'is-error');
      return;
    }
    if (monthlyRentRequired && (need.minMonthlyRent === null || need.maxMonthlyRent === null)) {
      setMessage('#needMessage', 'برای این نوع معامله، حداقل و حداکثر اجارهٔ ماهانه را وارد کنید.', 'is-error');
      return;
    }
    if (need.minArea !== null && need.minArea <= 0) {
      setMessage('#needMessage', 'حداقل متراژ، در صورت ثبت، باید بزرگ‌تر از صفر باشد.', 'is-error');
      return;
    }
    if (need.minBudget > need.maxBudget) {
      setMessage('#needMessage', 'حداقل بودجه نمی‌تواند بیشتر از حداکثر بودجه باشد.', 'is-error');
      return;
    }
    if (need.minArea !== null && need.maxArea !== null && need.minArea > need.maxArea) {
      setMessage('#needMessage', 'حداقل متراژ نمی‌تواند بیشتر از حداکثر متراژ باشد.', 'is-error');
      return;
    }
    if (monthlyRentRequired && need.minMonthlyRent > need.maxMonthlyRent) {
      setMessage('#needMessage', 'حداقل اجارهٔ ماهانه نمی‌تواند بیشتر از حداکثر آن باشد.', 'is-error');
      return;
    }

    state.needs.unshift(need);
    if (!saveNeeds()) {
      state.needs.shift();
      renderAll();
      setMessage('#needMessage', 'ذخیره‌سازی مرورگر در دسترس نیست؛ نیاز ثبت نشد.', 'is-error');
      return;
    }
    els.needForm.reset();
    els.needDealType.value = 'خرید';
    syncNeedBudgetLabels();
    setMessage('#needMessage', `نیاز فرضی «${need.alias}» ثبت شد؛ اکنون می‌توانید تطابق را جست‌وجو کنید.`, 'is-success');
  }

  function runMatch() {
    const need = state.needs.find((item) => item.id === els.matchSelect.value);
    if (!need) {
      els.matchSummary.innerHTML = '<strong>یک نیاز ثبت‌شده را انتخاب کنید.</strong><span>پس از انتخاب، ارزیابی شروع می‌شود.</span>';
      els.matchResults.innerHTML = '';
      return;
    }
    if (state.properties.length === 0) {
      els.matchSummary.innerHTML = '<strong>هنوز ملکی برای ارزیابی ثبت نشده است.</strong><span>یک ملک فرضی ثبت کنید یا دادهٔ فرضی را بارگذاری کنید.</span>';
      els.matchResults.innerHTML = '';
      return;
    }

    const results = state.properties.map((property) => ReinMatching.evaluateProperty(property, need));
    const statusRank = { complete: 0, partial: 1, insufficient: 2, 'no-match': 3 };
    results.sort((a, b) => statusRank[a.status] - statusRank[b.status] || b.passes - a.passes);
    const matchedCount = results.filter((result) => result.status === 'complete').length;

    els.matchSummary.innerHTML = `
      <strong>${faNumber(matchedCount)} ملک با تمام معیارهای «${escapeHtml(need.alias)}» سازگار است.</strong>
      <span>${faNumber(results.length)} ملک بررسی شد؛ برای هر مورد دلیل را ببینید.</span>
    `;

    els.matchResults.innerHTML = results.map((result) => `
      <article class="match-card match-${result.status}">
        <div class="match-card-header">
          <div>
            <div class="record-topline">
              <span class="code-chip">${escapeHtml(result.property.code)}</span>
              <span class="deal-chip">${escapeHtml(result.property.dealType)}</span>
            </div>
            <h3>${escapeHtml(result.property.city)}، ${escapeHtml(result.property.neighborhood)}</h3>
            <p>${propertyAmountLabel(result.property)} · ${faNumber(result.property.area)} متر · ${faNumber(result.property.rooms)} اتاق</p>
          </div>
          <div class="match-status">
            <strong>${({complete: 'تطابق کامل', partial: 'تطابق نسبی', insufficient: 'اطلاعات ناکافی', 'no-match': 'عدم تطبیق'})[result.status]}</strong>
            <span>${faNumber(result.passes)} از ${faNumber(result.total)} معیار</span>
          </div>
        </div>
        <ul class="reason-list">
          ${result.criteria.map((item) => `
            <li class="${item.applicable ? (item.passed ? 'is-pass' : 'is-fail') : 'is-neutral'}">
              <span aria-hidden="true">${item.applicable ? (item.passed ? '✓' : '×') : '–'}</span>
              <span>${escapeHtml(item.applicable ? (item.passed ? item.passedText : item.failedText) : item.passedText)}</span>
            </li>
          `).join('')}
        </ul>
      </article>
    `).join('');
  }

  function loadDemoData() {
    const demoProperties = [
      {
        id: 'demo-p-101',
        code: 'P-101',
        city: 'تهران',
        neighborhood: 'سعادت‌آباد',
        dealType: 'فروش',
        price: 3200000000,
        deposit: null,
        monthlyRent: null,
        area: 105,
        rooms: 2,
        notes: 'نمونهٔ فرضی؛ نورگیر و طبقهٔ سوم',
      },
      {
        id: 'demo-p-102',
        code: 'P-102',
        city: 'تهران',
        neighborhood: 'سعادت‌آباد',
        dealType: 'فروش',
        price: 4100000000,
        deposit: null,
        monthlyRent: null,
        area: 138,
        rooms: 3,
        notes: 'نمونهٔ فرضی؛ متراژ بالاتر از نیاز',
      },
      {
        id: 'demo-p-103',
        code: 'P-103',
        city: 'تهران',
        neighborhood: 'پونک',
        dealType: 'اجاره',
        price: null,
        deposit: 450000000,
        monthlyRent: 22000000,
        area: 78,
        rooms: 2,
        notes: 'نمونهٔ فرضی؛ مناسب سناریوی اجاره',
      },
    ];
    const demoNeeds = [
      {
        id: 'demo-n-101',
        alias: 'مشتری-الف',
        city: 'تهران',
        neighborhood: 'سعادت‌آباد',
        dealType: 'خرید',
        minBudget: 2800000000,
        maxBudget: 3500000000,
        minDeposit: null,
        maxDeposit: null,
        minMonthlyRent: null,
        maxMonthlyRent: null,
        minArea: 90,
        maxArea: 120,
        rooms: 2,
        notes: 'نمونهٔ فرضی برای آزمون تطابق',
      },
    ];

    const existingCodes = new Set(state.properties.map((item) => normalize(item.code)));
    const existingNeeds = new Set(state.needs.map((item) => normalize(item.alias)));
    state.properties.push(...demoProperties.filter((item) => !existingCodes.has(normalize(item.code))));
    state.needs.push(...demoNeeds.filter((item) => !existingNeeds.has(normalize(item.alias))));
    writeStorage(STORAGE_KEYS.properties, state.properties);
    writeStorage(STORAGE_KEYS.needs, state.needs);
    renderAll();
    showView('match');
    els.matchSelect.value = state.needs.find((item) => item.id === 'demo-n-101')?.id || '';
    runMatch();
  }

  function showView(viewName) {
    document.querySelectorAll('[data-view]').forEach((view) => {
      view.classList.toggle('is-active', view.dataset.view === viewName);
    });
    document.querySelectorAll('[data-nav]').forEach((button) => {
      button.classList.toggle('is-active', button.dataset.nav === viewName);
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function bindEvents() {
    els.propertyForm.addEventListener('submit', handlePropertySubmit);
    els.needForm.addEventListener('submit', handleNeedSubmit);
    els.propertyDealType.addEventListener('change', syncPropertyPriceFields);
    els.needDealType.addEventListener('change', syncNeedBudgetLabels);
    document.querySelector('#runMatch').addEventListener('click', runMatch);
    document.querySelectorAll('[data-nav]').forEach((button) => {
      button.addEventListener('click', () => showView(button.dataset.nav));
    });
    document.querySelectorAll('[data-action="load-demo"]').forEach((button) => {
      button.addEventListener('click', loadDemoData);
    });
  }

  syncPropertyPriceFields();
  syncNeedBudgetLabels();
  renderAll();
  bindEvents();
})();
