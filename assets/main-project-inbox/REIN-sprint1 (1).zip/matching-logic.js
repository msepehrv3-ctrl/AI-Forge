(() => {
  'use strict';

  const RENTAL_TYPES = ['رهن', 'اجاره', 'رهن و اجاره'];
  const MONTHLY_RENT_TYPES = ['اجاره', 'رهن و اجاره'];
  const DEAL_COMPATIBILITY = {
    خرید: ['فروش'],
    فروش: ['خرید'],
    رهن: ['رهن'],
    اجاره: ['اجاره'],
    'رهن و اجاره': ['رهن و اجاره'],
  };

  function normalize(value) {
    return String(value || '')
      .trim()
      .replace(/\s+/g, ' ')
      .replace(/ي/g, 'ی')
      .replace(/ك/g, 'ک')
      .toLocaleLowerCase('fa-IR');
  }

  function parseNumber(value) {
    const persian = '۰۱۲۳۴۵۶۷۸۹';
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    const normalized = String(value ?? '')
      .replace(/[۰-۹]/g, (digit) => persian.indexOf(digit))
      .replace(/[٠-٩]/g, (digit) => arabic.indexOf(digit))
      .replace(/[٬,\s]/g, '');
    if (normalized === '') return null;
    const number = Number(normalized);
    return Number.isFinite(number) ? number : null;
  }

  function faNumber(value) {
    return new Intl.NumberFormat('fa-IR').format(value || 0);
  }

  function money(value) {
    return `${new Intl.NumberFormat('fa-IR').format(value || 0)} تومان`;
  }

  function rangeText(min, max, suffix) {
    if (min !== null && min !== undefined && max !== null && max !== undefined) return `${faNumber(min)} تا ${faNumber(max)} ${suffix}`;
    if (min !== null && min !== undefined) return `از ${faNumber(min)} ${suffix}`;
    if (max !== null && max !== undefined) return `تا ${faNumber(max)} ${suffix}`;
    return 'بدون محدودیت';
  }

  function hasNumber(value) {
    return value !== null && value !== undefined && Number.isFinite(value);
  }

  function dealCompatibility(propertyType, needType) {
    return (DEAL_COMPATIBILITY[needType] || []).includes(propertyType);
  }

  function legacyBudgetRange(need) {
    return { min: need.minBudget, max: need.maxBudget };
  }

  function needRange(need, kind) {
    if (kind === 'price') return legacyBudgetRange(need);
    if (kind === 'deposit') {
      return {
        min: hasNumber(need.minDeposit) ? need.minDeposit : need.minBudget,
        max: hasNumber(need.maxDeposit) ? need.maxDeposit : need.maxBudget,
      };
    }
    return { min: need.minMonthlyRent, max: need.maxMonthlyRent };
  }

  function propertyFinancialFields(property) {
    if (property.dealType === 'رهن') return [{ key: 'deposit', label: 'ودیعه', value: property.deposit }];
    if (property.dealType === 'اجاره' || property.dealType === 'رهن و اجاره') {
      return [
        { key: 'deposit', label: 'ودیعه', value: property.deposit },
        { key: 'monthlyRent', label: 'اجارهٔ ماهانه', value: property.monthlyRent },
      ];
    }
    return [{ key: 'price', label: 'قیمت کل', value: property.price }];
  }

  function criterion(label, passed, passedText, failedText, applicable = true, missing = false, critical = false) {
    return { label, passed, passedText, failedText, applicable, missing, critical };
  }

  function evaluateProperty(property, need) {
    const hasNeighborhood = Boolean(normalize(need.neighborhood));
    const criteria = [
      criterion(
        'شهر',
        normalize(property.city) === normalize(need.city),
        `شهر: ${property.city} با شهر موردنظر یکسان است.`,
        `شهر: ملک در ${property.city} است، اما نیاز برای ${need.city} ثبت شده است.`,
        true,
        false,
        true
      ),
      criterion(
        'محله',
        !hasNeighborhood || normalize(property.neighborhood) === normalize(need.neighborhood),
        hasNeighborhood ? `محله: ${property.neighborhood} با محلهٔ موردنظر یکسان است.` : 'محله: برای این نیاز محدودیتی ثبت نشده است.',
        `محله: ملک در ${property.neighborhood} است، اما محلهٔ موردنظر ${need.neighborhood} است.`,
        hasNeighborhood
      ),
      criterion(
        'نوع معامله',
        dealCompatibility(property.dealType, need.dealType),
        `نوع معامله: «${property.dealType}» با نیاز «${need.dealType}» سازگار است.`,
        `نوع معامله: ملک «${property.dealType}» است، اما نیاز «${need.dealType}» ثبت شده است.`,
        true,
        false,
        true
      ),
    ];

    const compatible = dealCompatibility(property.dealType, need.dealType);
    const propertyFields = propertyFinancialFields(property);
    propertyFields.forEach((field) => {
      const range = needRange(need, field.key);
      const valuePresent = hasNumber(field.value);
      const rangePresent = hasNumber(range.min) && hasNumber(range.max);
      const missing = !valuePresent || !rangePresent;
      const passed = !missing && field.value >= range.min && field.value <= range.max;
      const rangeLabel = field.key === 'monthlyRent' ? 'اجارهٔ ماهانه' : field.label;
      criteria.push(criterion(
        rangeLabel,
        passed,
        `${rangeLabel}: ${money(field.value)} در بازهٔ ${money(range.min)} تا ${money(range.max)} است.`,
        missing
          ? `${rangeLabel}: مبلغ ملک یا بازهٔ لازم برای نیاز ثبت نشده است؛ تطبیق کامل قابل تأیید نیست.`
          : `${rangeLabel}: ${money(field.value)} خارج از بازهٔ ${money(range.min)} تا ${money(range.max)} است.`,
        true,
        missing,
        true
      ));
    });

    const areaPresent = hasNumber(property.area);
    const roomsPresent = hasNumber(property.rooms);
    const areaApplicable = hasNumber(need.minArea) || hasNumber(need.maxArea);
    const roomsApplicable = hasNumber(need.rooms) && need.rooms > 0;
    const areaPassed = areaPresent && (!hasNumber(need.minArea) || property.area >= need.minArea) && (!hasNumber(need.maxArea) || property.area <= need.maxArea);
    const roomsPassed = roomsPresent && (!roomsApplicable || property.rooms >= need.rooms);
    criteria.push(criterion(
      'متراژ',
      areaPassed,
      `متراژ: ${faNumber(property.area)} متر در محدودهٔ درخواست است.`,
      !areaPresent ? 'متراژ: متراژ ملک ثبت نشده و قابل تأیید نیست.' : `متراژ: ${faNumber(property.area)} متر با محدودهٔ ${rangeText(need.minArea, need.maxArea, 'متر')} سازگار نیست.`,
      areaApplicable,
      !areaPresent,
      areaApplicable
    ));
    criteria.push(criterion(
      'اتاق',
      roomsPassed,
      `اتاق: ${faNumber(property.rooms)} اتاق، حداقل ${faNumber(need.rooms || 0)} اتاق را پوشش می‌دهد.`,
      !roomsPresent ? 'اتاق: تعداد اتاق ملک ثبت نشده و قابل تأیید نیست.' : `اتاق: ملک ${faNumber(property.rooms)} اتاق دارد، اما حداقل ${faNumber(need.rooms)} اتاق لازم است.`,
      roomsApplicable,
      !roomsPresent,
      roomsApplicable
    ));

    const applicableCriteria = criteria.filter((item) => item.applicable);
    const passes = applicableCriteria.filter((item) => item.passed).length;
    const missingCriticalData = applicableCriteria.some((item) => item.missing && item.critical);
    const failedCritical = applicableCriteria.some((item) => !item.passed && !item.missing && item.critical);
    const passed = compatible && passes === applicableCriteria.length && !missingCriticalData;
    // Definitive required mismatches always win over missing data. Only when no
    // definitive mismatch exists can missing critical data become insufficient.
    const status = passed ? 'complete' : (failedCritical ? 'no-match' : (missingCriticalData ? 'insufficient' : 'partial'));
    return { property, criteria, passed, passes, total: applicableCriteria.length, status };
  }

  window.ReinMatching = {
    RENTAL_TYPES,
    MONTHLY_RENT_TYPES,
    dealCompatibility,
    evaluateProperty,
    needRange,
    propertyFinancialFields,
    parseNumber,
  };
})();
