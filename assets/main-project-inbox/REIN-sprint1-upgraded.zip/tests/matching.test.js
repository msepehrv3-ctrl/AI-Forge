const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const context = { window: {}, Intl, Number, String, console };
vm.runInNewContext(fs.readFileSync('matching-logic.js', 'utf8'), context, { filename: 'matching-logic.js' });
const { evaluateProperty, parseNumber } = context.window.ReinMatching;

const baseProperty = (overrides = {}) => ({
  city: 'تهران', neighborhood: 'سعادت‌آباد', dealType: 'فروش', price: 3200000000,
  deposit: null, monthlyRent: null, area: 100, rooms: 2, ...overrides,
});
const baseNeed = (overrides = {}) => ({
  city: 'تهران', neighborhood: 'سعادت‌آباد', dealType: 'خرید',
  minBudget: 2800000000, maxBudget: 3500000000,
  minDeposit: null, maxDeposit: null, minMonthlyRent: null, maxMonthlyRent: null,
  minArea: 90, maxArea: 120, rooms: 2, ...overrides,
});
const status = (property, need) => evaluateProperty(property, need).status;
const criterion = (property, need, label) => evaluateProperty(property, need).criteria.find((item) => item.label === label);

assert.equal(parseNumber('۳٬۲۰۰٬۰۰۰٬۰۰۰'), 3200000000, 'Persian digits and separators parse');
assert.equal(parseNumber('٣٢٠٠٠٠٠٠٠٠'), 3200000000, 'Arabic digits parse');

assert.equal(status(baseProperty(), baseNeed()), 'complete', '1. compatible buy/sell budget');
assert.equal(status(baseProperty({ price: 4100000000 }), baseNeed()), 'no-match', '2. sale outside budget');
assert.equal(status(baseProperty({ dealType: 'رهن', price: null, deposit: 500000000 }), baseNeed({ dealType: 'رهن', minBudget: 400000000, maxBudget: 600000000, minDeposit: 400000000, maxDeposit: 600000000, minArea: null, maxArea: null, rooms: null })), 'complete', '3a. compatible deposit');
assert.equal(status(baseProperty({ dealType: 'رهن', price: null, deposit: 700000000 }), baseNeed({ dealType: 'رهن', minBudget: 400000000, maxBudget: 600000000, minDeposit: 400000000, maxDeposit: 600000000, minArea: null, maxArea: null, rooms: null })), 'no-match', '3b. incompatible deposit');
assert.equal(status(baseProperty({ dealType: 'رهن', price: null, deposit: 500000000 }), { city: 'تهران', neighborhood: '', dealType: 'رهن', minBudget: 400000000, maxBudget: 600000000, minArea: null, maxArea: null, rooms: null }), 'complete', '11a. old mortgage need falls back to legacy budget');
assert.equal(status(baseProperty({ dealType: 'اجاره', price: null, deposit: 450000000, monthlyRent: 22000000 }), baseNeed({ dealType: 'اجاره', minBudget: 400000000, maxBudget: 500000000, minDeposit: 400000000, maxDeposit: 500000000, minMonthlyRent: 18000000, maxMonthlyRent: 25000000, minArea: null, maxArea: null, rooms: null })), 'complete', '4. compatible deposit and monthly rent');
assert.equal(status(baseProperty({ dealType: 'رهن و اجاره', price: null, deposit: 500000000, monthlyRent: 30000000 }), baseNeed({ dealType: 'رهن و اجاره', minBudget: 400000000, maxBudget: 600000000, minDeposit: 400000000, maxDeposit: 600000000, minMonthlyRent: 18000000, maxMonthlyRent: 25000000, minArea: null, maxArea: null, rooms: null })), 'no-match', '5. compatible deposit but rent too high');
assert.equal(status(baseProperty({ dealType: 'رهن و اجاره', price: null, deposit: 700000000, monthlyRent: 22000000 }), baseNeed({ dealType: 'رهن و اجاره', minBudget: 400000000, maxBudget: 600000000, minDeposit: 400000000, maxDeposit: 600000000, minMonthlyRent: 18000000, maxMonthlyRent: 25000000, minArea: null, maxArea: null, rooms: null })), 'no-match', '6. compatible rent but deposit too high');
assert.equal(status(baseProperty({ dealType: 'رهن و اجاره', price: null, deposit: 500000000, monthlyRent: null }), baseNeed({ dealType: 'رهن و اجاره', minBudget: 400000000, maxBudget: 600000000, minDeposit: 400000000, maxDeposit: 600000000, minMonthlyRent: 18000000, maxMonthlyRent: 25000000, minArea: null, maxArea: null, rooms: null })), 'insufficient', '7. missing required amount');
assert.equal(status(baseProperty(), baseNeed({ city: 'مشهد' })), 'no-match', '8a. city mismatch');
assert.equal(status(baseProperty({ dealType: 'فروش' }), baseNeed({ dealType: 'رهن' })), 'no-match', '8b. deal mismatch');
assert.equal(status(baseProperty({ area: 140 }), baseNeed()), 'no-match', '9. area outside range');
assert.equal(status(baseProperty(), baseNeed({ neighborhood: '' })), 'complete', '10. optional neighborhood omitted');
assert.equal(status(baseProperty({ dealType: 'رهن و اجاره', price: undefined, deposit: 500000000, monthlyRent: 22000000 }), {
  city: 'تهران', neighborhood: '', dealType: 'رهن و اجاره', minBudget: 400000000, maxBudget: 600000000,
  minArea: null, maxArea: null, rooms: null,
}), 'insufficient', '11. old rental need without new monthly range');
assert.equal(status(baseProperty({ price: -1 }), baseNeed()), 'no-match', '12a. negative property amount is not a valid match');
assert.equal(status(baseProperty({ price: 3200000000 }), baseNeed({ minBudget: 4000000000, maxBudget: 3000000000 })), 'no-match', '12b. inverted budget range cannot match');
assert.equal(criterion(baseProperty({ price: undefined }), baseNeed(), 'قیمت کل').missing, true, 'missing financial data is marked missing');

console.log('Sprint 1 matching tests: 21 PASS');
